//
//  ViewController.swift
//  multiViewApp
//
//  Created by Xt on 2/26/18.
//  Copyright © 2018 class. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var usernameTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!

    @IBAction func buttonTapped(_ sender: Any) {
        print("Button clicked")
        
        if(usernameTextField.text != "" && passwordTextField.text != ""){
            let secondViewController = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier:"SecondViewController") as! SecondViewController
            
            secondViewController.username = usernameTextField.text!
            self.present(secondViewController, animated:true, completion: nil)
        }
    }

    @IBAction func myUnwindAction(unwindSegue: UIStoryboardSegue){
        
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        //print("First View Controller will appear")
        passwordTextField.text = ""
        usernameTextField.text = ""
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        //print("First View Controller loaded")
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        print("PREPARE TO SHOW SecondViewController")
        let secondViewController = segue.destination as! SecondViewController
        
        secondViewController.username = usernameTextField.text!
    }
    
    override func shouldPerformSegue(withIdentifier identifier: String, sender: Any?) -> Bool
    {
        print("SHOULD I PERFORM?")
        //Iamcool123
        if(usernameTextField.text == "" || passwordTextField.text == ""){
            return false
        }
        
        return true
    }
    
}

