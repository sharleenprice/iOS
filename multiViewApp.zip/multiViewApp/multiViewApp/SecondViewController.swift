//
//  SecondViewController.swift
//  multiViewApp
//
//  Created by Xt on 2/26/18.
//  Copyright © 2018 class. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {
    
    @IBOutlet weak var usernameLabel: UILabel!
    var username = ""

    @IBAction func buttonTapped(_ sender: Any) {
        print("SecondViewController buttonTapped")
        
        navigationController?.popViewController(animated: true)
        
        dismiss(animated: true, completion: nil)
    }

    @IBAction func myUnwindAction(unwindSegue: UIStoryboardSegue){
        print("SecondViewController UNWIND")
    }

    
    override func viewDidLoad() {
        super.viewDidLoad()
        print("SecondViewController loaded")
        usernameLabel.text = username
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }

}
