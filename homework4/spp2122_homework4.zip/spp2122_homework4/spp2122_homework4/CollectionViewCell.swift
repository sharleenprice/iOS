//
//  CollectionViewCell.swift
//  spp2122_homework4
//
//  Created by Sharleen Price on 2/22/18.
//  Copyright © 2018 Sharleen Price. All rights reserved.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
